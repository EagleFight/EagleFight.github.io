<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<!--<?php echo ($data["id"]); ?>-->
<!--<?php echo ($data["name"]); ?><br/>-->
<!--<?php echo ($data['id']); ?><br/>-->
<!--<?php echo ($data['name']); ?>-->
<!--<?php echo ($data->id); ?>-->
<!--<?php echo ($data->name); ?>-->
<!--<?php echo ($data->id); ?>-->
<!--<?php echo ($data->name); ?>-->
<?php echo (md5($data["name"])); ?>
<?php echo (date("y-m-d",$create_time)); ?>
</body>
</html>