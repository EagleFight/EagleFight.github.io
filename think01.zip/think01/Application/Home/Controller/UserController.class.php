<?php
namespace Home\Controller;
use Think\Controller;
class UserController extends Controller {
    function test(){

        //适用对象的方式查询
//        $user = M('User');
//        $condition = new \stdClass();
//        $condition->id=1;
//        $condition->user='wu1';
//        $condition->_logic = 'OR';
//        dump($user->where($condition)->select());

        //条件查询
//        $user = M('User');
//        $map['id'] = array('eq',1);
//        $map['id'] = array('gt',1);
//        $map['user'] = array('like','%w%');
//        $map['user'] = array('notlike','%1%');
//          $map['user'] = array('like',array('%w%','%1%'));
//        $map['user'] = array('like',array('%w%','%1%'),'and');
//        $map['id'] = array('between','1,3');
//        $map['id'] = array('between',array('1','3'));
//        $map['id'] = array('not between',array('1','3'));
//        $map['id'] = array('in','1,2');
//        $map['id'] = array('in',array('1','2','4'));
//        $map['id'] = array('not in',array('1','2','4'));
                //还可以自定义
//            $map['id'] = array('exp','=4');
//        $map['id'] = array('exp','<4');
//        $map['id'] = array('exp','in(1,2,3)');
//        $map['id'] = array('exp','=1');
//        $map['user'] = array('exp','="wu4"');
//        $map['_logic'] = 'OR';
//        dump($user->where($map)->select());


//        $name = 'thinkphp';
//        $this->assign('name',$name);
//        $this->display();

        $data['id'] = 20;
        $data['name'] = 'tangyanwu';
        $this->assign('data',$data);
        $this->display();
    }
}